<?php

$db = mysql_connect("localhost", "fwdbu11233", "meexubon");
if (!db) { 
  die("Couldn't connect to MySQL"); 
} 

mysql_select_db("fwdbd11233",$db) 
  or die("Select Database Error: ".mysql_error()); 
 
$result = mysql_query("SELECT * FROM `NumWalks2` WHERE `Label` > CURDATE() - 7 " ,$db); 
$alldata = array();

while ($row = mysql_fetch_assoc($result)) {
      array_push($alldata,$row);
}

// Obtain a list of columns
foreach ($alldata as $key => $row) {
    $num[$key]  = $row['Num'];
    $label[$key] = $row['Label'];
}
// Sort the data with volume descending, edition ascending
// Add $data as the last parameter, to sort by the common key
array_multisort($label, SORT_ASC, $num, SORT_ASC, $alldata);

$data = json_encode($alldata);
echo $data; 

/*
ToDo: convert from mysql to PDO
}*/

?>





