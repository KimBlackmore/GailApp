var walks = [];
var times = [];
var totalWalks = 0;

function recordWalks(n,d,newEntry){
	//alert(n);
	walks.push(n);
	totalWalks += ~~n;
	//alert("Total walks:" + totalWalks);
	if(d===undefined){ //make date equal today
		currentDate = new Date();
		month = currentDate.getMonth()+1;
		//walkDate is a string for display in the graph
		walkDate = currentDate.getFullYear() + "-" + month + "-" + currentDate.getDate() ;
	} else {
		walkDate = d;
	}
	times.push(walkDate); //alert(times);	 
	//send new data to the database
	if(newEntry==1){
		year=d.substring(0,4);
		month = d.substring(5,7);
		day = d.substring(8,10);
		datenodash = year+month+day;
		postNum(n,~~datenodash);
		alert("New total walks:" + totalWalks);
	}
}


var lineChartData = {
	labels : times,
	datasets : [
		{
			label: "My Walks",
			fillColor : "rgba(34,148,186,0.2)",
			strokeColor : "rgba(20,99,125,1)",
			pointColor : "rgba(0,0,0,1)",
			pointStrokeColor : "#fff",
			pointHighlightFill : "#fff",
			pointHighlightStroke : "rgba(220,220,220,1)",
			data : walks
		}
	]

}
	
$(document).on("pageshow","#walkHistory",function(){
	var ctx = document.getElementById("canvas").getContext("2d");
	window.myLine = new Chart(ctx).Line(lineChartData, {
		responsive: true
	});
});

$.ajax({ 
    type: "POST",
    url: "http://home.exetel.com.au/blackmores/GailApp/getNums.php",
    dataType: "json",
  	data: {  //this bit os for sending data to the database
  	}
}).done(function( data ) { //this bit is for putting retrieved data into the walks array
	//alert('got Nums');
	$.each(data, function(index, element) { //
		//alert(element.Num);
		recordWalks(element.Num,element.Label,0);
	});
	//alert("Retrieved walks: "+ walks);
	alert("Total walks:" + totalWalks);
}).fail(function() { 
 	}
);

function postNum(n,d){
	//alert("in postNum: num "+n+" day "+d);
	//alert(n);
	//alert(d);
;	$.ajax({ 
	    type: "POST",
	    url: "http://home.exetel.com.au/blackmores/GailApp/postNum.php", 
	    data:{num:n, date:d} 
	}).done(function( data ) { 
			//alert("Submitted");
	}).fail(function() {  alert("I failed");
	});

}


	

