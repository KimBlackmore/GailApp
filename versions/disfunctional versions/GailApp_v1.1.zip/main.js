var walks = [];
var times = [];

function recordWalks(n,d,newEntry){
	walks.push(n);
	//alert("Passed date: "+ d);
	if(d===undefined){
	 	//alert("Passed date: "+ d);
		currentDate = new Date();
		//alert("created date: "+ currentDate);
		month = currentDate.getMonth()+1;
		walkDate = currentDate.getFullYear() + "-" + month + "-" + currentDate.getDate() ;
		// make it a number
		postDate = currentDate.getFullYear()*10000+ month*100 + currentDate.getDate() ; 
		// could make it a string without hyphens, but that doesn't post to database properly
		//postDate = currentDate.getFullYear()+""+month+""+ currentDate.getDate() ; 
		//alert("and walk date: "+ walkDate);
	}else{
		walkDate = d;
	}
	//currentDate = new Date();
	//need to change getSeconds to get Date
	times.push(walkDate);
	//alert(times);	
	if(newEntry===undefined){
		//alert(times);
		//alert("and post date: "+ postDate);
		postNum(n,postDate);
	}
}

var lineChartData = {
	labels : times,
	datasets : [
		{
			label: "My Walks",
			fillColor : "rgba(34,148,186,0.2)",
			strokeColor : "rgba(20,99,125,1)",
			pointColor : "rgba(0,0,0,1)",
			pointStrokeColor : "#fff",
			pointHighlightFill : "#fff",
			pointHighlightStroke : "rgba(220,220,220,1)",
			data : walks
		}
	]

}
	
$(document).on("pageshow","#graph",function(){
	var ctx = document.getElementById("canvas").getContext("2d");
	window.myLine = new Chart(ctx).Line(lineChartData, {
		responsive: true
	});
});

$.ajax({ 
    type: "POST",
    url: "http://home.exetel.com.au/blackmores/DavidApp/getNums.php",
    dataType: "json",
  	data: {  //this bit os for sending data to the database
  	}
}).done(function( data ) { //this bit is for putting retrieved data into the walks array
	//alert('got Nums');
	$.each(data, function(index, element) { //
		//alert(element.Num);
		recordWalks(element.Num,element.Label,true);
	});
	//alert("Retrieved walks: "+ walks);
}).fail(function() { 
 	}
);


//alert ("OK do something");
//postNum(2,"20150319");

function postNum(n,d){
	//alert("in postNum: num "+n+" day "+d);
	//alert(n);
	//alert(d);
;	$.ajax({ 
	    type: "POST",
	    url: "http://home.exetel.com.au/blackmores/DavidApp/postNum.php", 
	    data:{num:n, date:d} 
	}).done(function( data ) { 
			//alert("Submitted");
	}).fail(function() {  alert("I failed");
	});

}


	

