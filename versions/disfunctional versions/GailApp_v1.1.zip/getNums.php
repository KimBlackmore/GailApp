<?php

$db = mysql_connect("localhost", "fwdbu11233", "meexubon");
if (!db) { 
  die("Couldn't connect to MySQL"); 
} 

mysql_select_db("fwdbd11233",$db) 
  or die("Select Database Error: ".mysql_error()); 

//echo("I'm in");
 
$result = mysql_query("SELECT * FROM NumWalks2",$db); 
$alldata = array();

while ($row = mysql_fetch_assoc($result)) {
      array_push($alldata,$row);
}
$data = json_encode($alldata);
echo $data; 

/*
ToDo: convert from mysql to PDO
}*/

?>





